﻿using System;

namespace GurchamanSidhu_log_BackEnd_CodeChallenge.Models
{
    public class Department
    {
        public int departmentId { get; set; }
        public string name { get; set; }
        public string address { get; set; }
    }
}

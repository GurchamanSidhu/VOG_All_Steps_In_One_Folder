﻿namespace GurchamanSidhu_log_BackEnd_CodeChallenge.Models
{
    public class Employee
    {
        public int departmentId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string jobTitle { get; set; }
        public string addressOfResidence { get; set; }
    }
}

﻿using GurchamanSidhu_log_BackEnd_CodeChallenge.Models;
using System.Collections.Generic;
using System.Linq;
using VogCodeChallenge.API.Services;

namespace VogCodeChallenge.API.Database
{
    public class DbEmployeeRepository : IEmployeeRepository
    {
        private readonly EmployeeDbContext dbContext;

        public DbEmployeeRepository(EmployeeDbContext dbContext)
        {
            this.dbContext = dbContext;
            this.dbContext.Employees.RemoveRange(this.dbContext.Employees);
            this.dbContext.Departments.RemoveRange(this.dbContext.Departments);
            this.dbContext.Employees.AddRange(DefaultData.InsertDefaultEmployeeData());
            this.dbContext.Departments.AddRange(DefaultData.InsertDefaultDepartmentData());
            this.dbContext.SaveChanges();
        }

        public IEnumerable<Employee> GetAll()
        {
            return dbContext.Employees;
        }

        public IList<Employee> ListAll()
        {
            return dbContext.Employees.ToList();
        }

        public IEnumerable<Employee> GetAllByDepartmentId(int departmentId)
        {
            IEnumerable<Employee> employees = ListAll();
            return dbContext.Employees.Where(x => x.departmentId.Equals(departmentId));
        }
    }
}

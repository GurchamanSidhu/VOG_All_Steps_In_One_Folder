﻿using System.ComponentModel.DataAnnotations;

namespace GurchamanSidhu_log_BackEnd_CodeChallenge.Models
{
    public class Employee
    {
        [Key]
        public int employeeId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string jobTitle { get; set; }
        public string addressOfResidence { get; set; }
        public int departmentId { get; set; }
    }
}
